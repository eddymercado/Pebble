This directory open sources select files from the Firebase Analytics SDK. Note
that there is no open source infrastructure to build or package them.
